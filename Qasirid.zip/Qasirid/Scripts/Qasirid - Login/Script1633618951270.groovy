import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.qasir.id/sign-in')

WebUI.click(findTestObject('Object Repository/Login/Page_Masuk/a_Email'))

WebUI.click(findTestObject('Object Repository/Login/Page_Masuk/input_No. PIN_submit-btn-signin'))

WebUI.verifyElementPresent(findTestObject('Object Repository/Login/Page_Masuk/label_Email wajib diisi'), 0)

WebUI.verifyElementPresent(findTestObject('Object Repository/Login/Page_Masuk/label_PIN wajib diisi'), 0)

WebUI.setText(findTestObject('Object Repository/Login/Page_Masuk/input_No. Handphone_email'), 'irni')

WebUI.verifyElementPresent(findTestObject('Object Repository/Login/Page_Masuk/label_Format email salah'), 0)

WebUI.setText(findTestObject('Object Repository/Login/Page_Masuk/input_No. Handphone_email'), 'irninuranisa@gmail.com')

WebUI.click(findTestObject('Object Repository/Login/Page_Masuk/input_No. PIN_submit-btn-signin'))

WebUI.verifyElementPresent(findTestObject('Object Repository/Login/Page_Masuk/label_PIN wajib diisi'), 0)

WebUI.click(findTestObject('Object Repository/Login/Page_Masuk/div_PIN wajib diisiNo. PIN'))

WebUI.setEncryptedText(findTestObject('Object Repository/Login/Page_Masuk/input_Email_password'), 'znkpQqlTkv4=')

WebUI.click(findTestObject('Object Repository/Login/Page_Masuk/input_No. PIN_submit-btn-signin'))

WebUI.waitForElementPresent(findTestObject('Object Repository/Login/Page_Masuk/div_InformasiPassword kamu salahOK'), 0)

WebUI.verifyElementPresent(findTestObject('Object Repository/Login/Page_Masuk/div_InformasiPassword kamu salahOK'), 0)

WebUI.verifyElementPresent(findTestObject('Object Repository/Login/Page_Masuk/h3_Informasi'), 0)

WebUI.verifyElementPresent(findTestObject('Object Repository/Login/Page_Masuk/div_Password kamu salah'), 0)

WebUI.verifyElementClickable(findTestObject('Object Repository/Login/Page_Masuk/div_InformasiPassword kamu salahOK'))

WebUI.click(findTestObject('Object Repository/Login/Page_Masuk/div_OK'))

WebUI.setText(findTestObject('Object Repository/Login/Page_Masuk/input_No. Handphone_email'), 'irninuranisa@gmail.com')

WebUI.setEncryptedText(findTestObject('Object Repository/Login/Page_Masuk/input_Email_password'), 'aeHFOx8jV/A=')

WebUI.click(findTestObject('Object Repository/Login/Page_Masuk/input_No. PIN_submit-btn-signin'))

WebUI.waitForPageLoad(0)

WebUI.navigateToUrl('https://agroceries-583728.qasir.id/dashboard?tokenWeb=GZK357AGX3')

WebUI.click(findTestObject('Object Repository/Login/Page_Home/span_Pusat'))

WebUI.click(findTestObject('Object Repository/Login/Page_Home/img_atau_img-circle avatar border-free'))

WebUI.click(findTestObject('Object Repository/Login/Page_Home/a_User Profile'))

WebUI.setText(findTestObject('Object Repository/Login/Page_Profile/input_First Name_last_name'), 'Anisa Anisa')

WebUI.click(findTestObject('Object Repository/Login/Page_Profile/button_Save'))

WebUI.waitForElementPresent(findTestObject('Object Repository/Login/Page_Profile/div_   Data saved successfully. Please re-l_c15ac5'), 
    0)

WebUI.verifyElementPresent(findTestObject('Object Repository/Login/Page_Profile/div_   Data saved successfully. Please re-l_c15ac5'), 
    0)

WebUI.verifyElementPresent(findTestObject('Object Repository/Login/Page_Profile/p_Data saved successfully. Please re-login _300be0'), 
    0)

WebUI.verifyElementClickable(findTestObject('Object Repository/Login/Page_Profile/button_'))

WebUI.click(findTestObject('Object Repository/Login/Page_Profile/button_'))

WebUI.setEncryptedText(findTestObject('Object Repository/Login/Page_Profile/input_Only filled if you want to be replace_ae8564'), 
    'aeHFOx8jV/A=')

WebUI.setEncryptedText(findTestObject('Object Repository/Login/Page_Profile/input_Enter the 6 digits old PIN_new_pin'), 
    'aeHFOx8jV/A=')

WebUI.setEncryptedText(findTestObject('Object Repository/Login/Page_Profile/input_Enter the new 6 digits PIN_new_pin_co_7caea3'), 
    'aeHFOx8jV/A=')

WebUI.click(findTestObject('Object Repository/Login/Page_Profile/button_Change PIN'))

WebUI.waitForElementPresent(findTestObject('Object Repository/Login/Page_Profile/div_   Data saved successfully. Please re-l_c15ac5'), 
    0)

WebUI.verifyElementPresent(findTestObject('Object Repository/Login/Page_Profile/div_   Data saved successfully. Please re-l_c15ac5'), 
    0)

WebUI.verifyElementPresent(findTestObject('Object Repository/Login/Page_Profile/p_Data saved successfully. Please re-login _300be0'), 
    0)

WebUI.verifyElementClickable(findTestObject('Object Repository/Login/Page_Profile/button_'))

WebUI.click(findTestObject('Object Repository/Login/Page_Profile/img_atau_img-circle avatar border-free'))

WebUI.click(findTestObject('Object Repository/Login/Page_Profile/a_Logout'))

