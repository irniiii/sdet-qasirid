<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>emailtab</name>
   <tag></tag>
   <elementGuidId>497df95e-dae8-4cd2-b457-8d8e24114316</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;trigger-tab-email&quot;]/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
</WebElementEntity>
