<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_FREE                                   _e11011</name>
   <tag></tag>
   <elementGuidId>521251d9-8d8d-4570-a5ac-cbae4e782104</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='navbarInstance']/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.topmenu-outer</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>topmenu-outer</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            
                
                        
                            
                        
                
                
                    
                        
                    
                
                
                    
                                                                        
                    
                
                
                    
                                                                        
                    
                
                
                
                    
                        
                            
                            
                                
                                        FREE
                                
                            
                        
                        
                        
                            
                                
                                
                                    
                                    FREE
                                
                                    
                                        Irni Anisa Anisa
                                        Admin
                                    
                                
                                
                            
                                                                                    
                                                        
                            
                                
                                    
                                    User Profile                                
                            
                             
                                                          
                                
                                    
                                    Business Information                                
                            
                                                        
                             
                             
                                
                                    
                                    Logout                                
                            
                        
                    
                                   
                
                
                
                                                          
                             
                            
                            
                                
                            
                        
                        
                                                          
                                 
                                    
                                 
                                
                                                                            
                                            Pusat
                                        
                                        
                                            All Outlets                                        
                                                                                                                                                                                                                        
                                            Pusat
                                        
                            
                                                     
                    
                
                

                
            
        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbarInstance&quot;)/div[@class=&quot;navbar-inner container-fluid&quot;]/div[@class=&quot;topmenu-outer&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='navbarInstance']/div/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='atau'])[1]/following::div[5]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Scan atau klik link dibawah ini :'])[1]/following::div[7]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div</value>
   </webElementXpaths>
</WebElementEntity>
